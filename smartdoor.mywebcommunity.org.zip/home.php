<!DOCTYPE html>
<html lang="vi">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LẬP TRÌNH HỆ THỐNG NHÚNG</title>
    <link rel="stylesheet" href="/index.php">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #ecf0f1;
            margin: 0;
            padding: 0;
        }

        header {
            background-color: #3498db;
            color: #fff;
            padding: 20px;
            text-align: center;
                display: flex;
            justify-content: space-around;
        }

        .header-wrapper {
            align-items: center;
        }

        .header-wrapper h1 {
            margin: 0 auto;
        }

        .user-management-label {
            color: #fff;
            font-size: 18px;
            margin-right: 20px;
        }

        table {
            font-family: Arial, sans-serif;
            border-collapse: collapse;
            width: 100%;
            margin: 20px 0;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            background-color: #fff;
            overflow-x: auto;
        }

        th,
        td {
            border: 1px solid #bdc3c7;
            text-align: center;
            /* Căn giữa nội dung trong ô */
            padding: 12px;
        }

        th {
            background-color: #2c3e50;
            color: #fff;
        }

        .temp-icon,
        .humd-icon,
        .gas-icon {
            width: 20px;
            height: 20px;
            margin-right: 5px;
        }

        .temp-icon {
            color: #e74c3c;
        }

        .humd-icon {
            color: #3498db;
        }

        .gas-icon {
            color: #27ae60;
        }

        tbody tr:hover {
            background-color: #ecf0f1;
            transition: background-color 0.3s ease;
        }

        tbody tr:nth-child(odd) {
            background-color: #f2f2f2;
        }

        tbody tr:hover td {
            background-color: #d5d8dc;
        }

        @media screen and (max-width: 600px) {
            table {
                overflow-x: auto;
            }
        }
            .user-management-button {
            background-color: blue;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
        }
            .header-wrapper {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background-color: #3498db;
            color: #fff;
            padding: 20px;
        }

        .header-wrapper h1 {
            margin: 0;
        }

        .dropdown {
            position: relative;
            display: inline-block;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: #f9f9f9;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            width: 200px;
        }

        .dropdown-content a,
        .dropdown-content button {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            background: none;
            border: none;
            width: 100%;
            text-align: left;
            cursor: pointer;
            font-size: 14px;
        }

        .dropdown-content a:hover,
        .dropdown-content button:hover {
            background-color: #f1f1f1;
        }

        .dropdown:hover .dropdown-content {
            display: block;
        }

        .avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            cursor: pointer;
        }
    </style>
</head>

<body>

    <header>
        <div class="header-wrapper">
        <h1 style="text-align: center;">NHÀ CỦA CÔNG TOÀN</h1>
        <div class="dropdown">
            <img src="https://ss-images.saostar.vn/wp700/pc/1613810558698/Facebook-Avatar_3.png" alt="Avatar" class="avatar">
            <div class="dropdown-content">
                <a href="index.php?page=manager">Quản lý Người Dùng</a>
                <a href="index.php?page=login">Đăng xuất</a>
            </div>
        </div>
    </div>
    </header>

    <table>
        <thead>
            <tr>
                <th>STT</th>
                <th>
                    <i class="fas fa-user"></i>
                    Người dùng
                </th>
                <th>
                    <i class="fas fa-id-card"></i>
                    Mã thẻ
                </th>
                <th>
                    <i class="fas fa-toggle-on"></i>
                    Trạng Thái
                </th>
                <th>
                    <i class="far fa-clock"></i>
                    Ngày giờ
                </th>
            </tr>
        </thead>
        <tbody>
            <?php
            $allData = $db->getAllData();
            foreach ($allData as $index => $each) {
                echo '<tr>';
                echo '<td>' . ($index + 1) . '</td>';
                echo '<td>' . $each['username'] . '</td>';
                echo '<td>' . $each['id_card'] . '</td>';
                echo '<td>' . $each['status'] . '</td>';
                echo '<td>' . $each['date'] . '</td>';
                echo '</tr>';
            }
            ?>
        </tbody>
    </table>

    <script>
        document.addEventListener("DOMContentLoaded", function () {

            var tbody = document.querySelector("tbody");

            var data = <?php echo json_encode($dataArray); ?>;

            data.forEach(function (row) {
                var newRow = document.createElement("tr");
                row.forEach(function (cell, index) {
                    cải tiến lại giao diện cho đẹp mắt là phù hợp hơn. Thêm 1 label "Quản lý người dùng"
                });
            });
        });
    </script>
</body>

</html>
