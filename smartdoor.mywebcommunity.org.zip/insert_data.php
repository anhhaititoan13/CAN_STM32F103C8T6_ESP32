<?php

require_once 'db_connection.php';

$db = new Database;
$db->connect();
				 
$cardRFID = $_GET["cardRFID"];

$allDataUser = $db->getAllDataUser();

date_default_timezone_set("Asia/Ho_Chi_Minh");
$time = date("H:i:s");
$date = date("Y-m-d");
$datetime=$date.' '.$time;

        if($cardRFID==1){
           if (!empty($allDataUser)) {
            $firstUser = $allDataUser[0];  
            $tenHienThi = $firstUser['tenHienThi'];
            $id_card = $firstUser['id_card'];

            $db->insertData($tenHienThi, $id_card, $datetime);
        } else {
            echo "No user data found.";
        }
}


?>