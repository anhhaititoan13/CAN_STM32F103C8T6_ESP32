<?php
if (isset($_GET['page'])) {
    $page = $_GET['page'];
} else {
    $page = 'login';
}
switch ($page) {
    case "home":
    	require_once "home.php";
    	break;
    case "login":
            if (isset($_POST['login'])) {
                $username = $_POST['username'];
                $password = $_POST['password'];
                $table = "account";
                $result = $db->checkUser($username, md5($password), $table);
            	if ($result == 0) {
                	$msg = "Tài khoản không tồn tại!";
            	} else {
               		header('Location:index.php?page=home');
            	}
        	}
    	require_once "login.php";
    	break;
    case "manager":
        	if (isset($_POST['add'])) {
                $username = $_POST['username'];
                $password = $_POST['password'];
                $id_card = $_POST['id_card'];
                $result = $db->insertUser($username, md5($password), $id_card);
               	header('Location:index.php?page=manager');
            	
        	}else if (isset($_POST['delete'])) {
                $username = $_POST['username'];
                $result = $db->deleteUser($username);
               	header('Location:index.php?page=manager');
        	}
        require_once "manager.php";
    	break;
}
?>