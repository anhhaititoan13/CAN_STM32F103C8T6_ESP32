<?php
// Dữ liệu mẫu
$temperatureData = [25, 27, 26, 28, 30, 29, 31];
$humidityData = [68, 70, 69, 71, 73, 72, 74];
$rfidData = [1, 0, 1, 1, 0, 1, 0]; // 1 đại diện cho "Có", 0 đại diện cho "Không"

// Thời gian mẫu cho các điểm dữ liệu
$timeLabels = ["7:00", "7:30", "8:00", "8:30", "9:00", "9:30", "10:00"];
?>

<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <style>
        /* CSS Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }

        body {
            background-color: #f5f5f5;
        }

        .dashboard {
            max-width: 1200px;
            margin: 20px auto;
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .tab-menu {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }

        .tab-menu button {
            padding: 10px 20px;
            border: none;
            background-color: #4CAF50;
            color: white;
            cursor: pointer;
        }

        .tab-menu button.locked {
            background-color: #ddd;
            cursor: not-allowed;
        }

        .graph-row {
            display: flex;
            align-items: center;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
        }

        .graph-label {
            width: 150px;
            font-size: 18px;
            color: #333;
        }

        .graph-container {
            flex: 1;
            padding: 10px;
        }
    </style>
</head>
<body>

<div class="dashboard">
    <!-- Tab Menu -->
    <div class="tab-menu">
        <button>Latest</button>
        <button>Last Hour</button>
        <button>6 Hours</button>
        <button>1 Day</button>
        <button class="locked">1 Week</button>
        <button class="locked">1 Month</button>
        <button class="locked">3 Months</button>
        <button class="locked">6 Months</button>
        <button class="locked">1 Year</button>
        <button class="locked">Custom</button>
    </div>

    <!-- Graph Rows -->
    <div class="graph-row">
        <div class="graph-label">THẺ RFID</div>
        <div class="graph-container">
            <canvas id="rfidChart"></canvas>
        </div>
    </div>
    <div class="graph-row">
        <div class="graph-label">NHIỆT ĐỘ</div>
        <div class="graph-container">
            <canvas id="temperatureChart"></canvas>
        </div>
    </div>
    <div class="graph-row">
        <div class="graph-label">ĐỘ ẨM</div>
        <div class="graph-container">
            <canvas id="humidityChart"></canvas>
        </div>
    </div>
    
</div>

<!-- Thêm thư viện Chart.js -->
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    // Dữ liệu từ PHP sang JavaScript
    const timeLabels = <?php echo json_encode($timeLabels); ?>;
    const temperatureData = <?php echo json_encode($temperatureData); ?>;
    const humidityData = <?php echo json_encode($humidityData); ?>;
    const rfidData = <?php echo json_encode($rfidData); ?>;
    
    // Biểu đồ Thẻ RFID
    const rfidCtx = document.getElementById('rfidChart').getContext('2d');
    new Chart(rfidCtx, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{
                label: 'Thẻ RFID',
                data: rfidData,
                borderColor: 'rgba(0, 123, 255, 1)',
                backgroundColor: 'rgba(0, 123, 255, 0.2)',
                fill: true,
            }]
        },
        options: {
            responsive: true,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1,
                        callback: function(value) {
                            return value === 1 ? 'Có' : 'Không';
                        }
                    }
                }
            }
        }
    });

    // Biểu đồ Nhiệt Độ
    const temperatureCtx = document.getElementById('temperatureChart').getContext('2d');
    new Chart(temperatureCtx, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{
                label: 'Nhiệt độ (°C)',
                data: temperatureData,
                borderColor: 'rgba(139, 195, 74, 1)',
                backgroundColor: 'rgba(139, 195, 74, 0.2)',
                fill: true,
            }]
        },
        options: { responsive: true }
    });

    // Biểu đồ Độ Ẩm
    const humidityCtx = document.getElementById('humidityChart').getContext('2d');
    new Chart(humidityCtx, {
        type: 'line',
        data: {
            labels: timeLabels,
            datasets: [{
                label: 'Độ ẩm (%)',
                data: humidityData,
                borderColor: 'rgba(156, 39, 176, 1)',
                backgroundColor: 'rgba(156, 39, 176, 0.2)',
                fill: true,
            }]
        },
        options: { responsive: true }
    });
</script>

</body>
</html>
