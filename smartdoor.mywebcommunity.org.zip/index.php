<?php

require_once 'db_connection.php';

$db = new Database;
$db->connect();

require_once('controller.php');




?>