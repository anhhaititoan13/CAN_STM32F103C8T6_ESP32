<?php
require_once 'db_connection.php';

$db = new Database;
$db->connect();

$cards = $db->getAllCard();

header('Content-Type: application/json');
echo json_encode($cards);
?>
